#Question 1. Develop a batch data ingest process to load the ODI match results and ball-by-ball innings data to a database of your
#choosing (as a default, you can use SQLite). The solution should include a step that downloads files directly from cricsheet.org 
#and performs any required preprocessing. The database schema should store match results and ball-by-ball innings data along with 
#the universe of players that appear across all matches. The process should be runnable from the command line, inclusive of 
#creating any dependencies (e.g. local file directories, the database, etc.). Please include a README.md file with instructions on
#how to build and run the ingest process to reproduce your results. 

#ANS :

import requests
import json
import zipfile
import io
import sqlite3

url = "https://cricsheet.org/downloads/odis_json.zip"
response = requests.get(url)
with zipfile.ZipFile(io.BytesIO(response.content)) as zip_file:
    json_filename = zip_file.namelist()[0]
    with zip_file.open(json_filename) as json_file:
        data = json.load(json_file)


conn = sqlite3.connect("odi_cricket.db")
cur = conn.cursor()

cur.execute('''CREATE TABLE IF NOT EXISTS match_results (
                match_id INTEGER PRIMARY KEY,
                team1 TEXT,
                team2 TEXT,
                winner TEXT
            )''')

cur.execute('''CREATE TABLE IF NOT EXISTS ball_by_ball (
                match_id INTEGER,
                over INTEGER,
                ball INTEGER,
                runs INTEGER,
                player TEXT,
                FOREIGN KEY(match_id) REFERENCES match_results(match_id)
            )''')


for match in data:
    match_id = match['match_id']
    team1 = match['team1']
    team2 = match['team2']
    winner = match['winner']

    cur.execute("INSERT INTO match_results VALUES (?, ?, ?, ?)", (match_id, team1, team2, winner))

    for ball in match['balls']:
        over = ball['over']
        ball_number = ball['ball']
        runs = ball['runs']
        player = ball['player']

        cur.execute("INSERT INTO ball_by_ball VALUES (?, ?, ?, ?, ?)", (match_id, over, ball_number, runs, player))

conn.commit()
conn.close()



