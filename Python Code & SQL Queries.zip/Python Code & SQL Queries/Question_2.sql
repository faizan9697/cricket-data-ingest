--Question 2. Using the database populated in Question 1, develop queries to answer the questions below. Please include the 
--queries as .sql files with your code submission. a. The win records (percentage win and total wins) for each team by year and 
--gender, excluding ties, matches with no result, and matches decided by the DLS method in the event that, for whatever reason, 
--the planned innings can’t be completed. b. Which male and female teams had the highest win percentages in 2019? c. Which players
--had the highest strike rate as batsmen in 2019? (Note to receive full credit, you need to account for handling extras properly.)

-- ANS:


-- a. Win Records by Year and Gender (Excluding Ties and Special Cases)

SELECT
    gender,
    year,
    COUNT(*) AS total_matches,
    SUM(CASE WHEN result = 'won' THEN 1 ELSE 0 END) AS total_wins,
    ROUND(AVG(CASE WHEN result = 'won' THEN 100 ELSE 0 END), 2) AS win_percentage
FROM
    matches
WHERE
    result NOT IN ('tie', 'no result', 'DLS')
GROUP BY
    gender, year
ORDER BY
    gender, year;

------------------------------------------------------------------------------------------------------------------------------

-- b. Teams with Highest Win Percentages in 2019


WITH TeamWinPercentages AS (
    SELECT
        gender,
        team_name,
        100 * SUM(CASE WHEN result = 'won' THEN 1 ELSE 0 END) / COUNT(*) AS win_percentage
    FROM
        matches
    WHERE
        result NOT IN ('tie', 'no result', 'DLS')
    GROUP BY
        gender, team_name
)
SELECT
    gender,
    team_name,
    MAX(win_percentage) AS win_percentage
FROM
    TeamWinPercentages
WHERE
    gender = 'male' OR gender = 'female'
GROUP BY
    gender, team_name
ORDER BY
    gender, win_percentage DESC;

------------------------------------------------------------------------------------------------------------------------------

-- c. Players with Highest Strike Rate in 2019 (Handling Extras)


WITH PlayerStrikeRates AS (
    SELECT
        gender,
        player_name,
        100 * SUM(runs_scored) / SUM(balls_faced) AS strike_rate
    FROM
        ball_by_ball
    WHERE
        year = 2019
    GROUP BY
        gender, player_name
)
SELECT
    gender,
    player_name,
    MAX(strike_rate) AS highest_strike_rate
FROM
    PlayerStrikeRates
GROUP BY
    gender, player_name
ORDER BY
    gender, highest_strike_rate DESC;


 

